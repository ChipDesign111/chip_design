set eda_work {/home/s2400011035/chip-fullstack-2026/eda_runs/uploads/20261103_int22_9970d6f/work}
set sim_inputs {/home/s2400011035/chip-fullstack-2026/eda_runs/uploads/20261104_191006_postsim_5edf6cd/postsim/inputs}
source {/home/s2400011035/chip-fullstack-2026/eda_runs/uploads/20261104_191006_postsim_5edf6cd/deploy/server/postsim/export_view.tcl}
