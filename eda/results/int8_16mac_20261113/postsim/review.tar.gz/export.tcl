set eda_work {/home/s2400011035/chip-fullstack-2026/eda_runs/uploads/20261113_main_16mac_bias22_c02527e/work}
set sim_inputs {/home/s2400011035/chip-fullstack-2026/eda_runs/uploads/20261113_173500_postsim_c2a7339/postsim/inputs}
source {/home/s2400011035/chip-fullstack-2026/eda_runs/uploads/20261113_173500_postsim_c2a7339/deploy/server/postsim/export_view.tcl}
