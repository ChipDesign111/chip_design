setMultiCpuUsage -localCpu 8
source {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261026_214621_5191064/work/pnr/my_soc_top/backup/step34.enc}
create_library_set -name qa_lib_tt -timing [list {/lec/pdk/tsmc180/tcb018gbwp7t_290a/TSMCHOME/digital/Front_End/timing_power_noise/NLDM/tcb018gbwp7t_270a/tcb018gbwp7ttc.lib} {/lec/pdk/tsmc180/tpd018nv_280a/TSMCHOME/digital/Front_End/timing_power_noise/NLDM/tpd018nv_280a/tpd018nvtc.lib} {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261026_214621_5191064/work/src/macro/RA1SHD_2048x32M8/RA1SHD_2048x32M8_tt_1p8_25C_syn.lib}]
create_rc_corner -name qa_rc_tt -temperature 25 -cap_table {/lec/pdk/tsmc180/tcb018gbwp7t_290a/TSMCHOME/digital/Back_End/lef/tcb018gbwp7t_270a/techfiles/captable/t018lo_1p6m_typical.captable}
create_delay_corner -name qa_delay_tt -library_set qa_lib_tt -rc_corner qa_rc_tt -si_enabled false
create_analysis_view -name qa_tt -constraint_mode func -delay_corner qa_delay_tt
create_library_set -name qa_lib_ss -timing [list {/lec/pdk/tsmc180/tcb018gbwp7t_290a/TSMCHOME/digital/Front_End/timing_power_noise/NLDM/tcb018gbwp7t_270a/tcb018gbwp7twc.lib} {/lec/pdk/tsmc180/tpd018nv_280a/TSMCHOME/digital/Front_End/timing_power_noise/NLDM/tpd018nv_280a/tpd018nvwc.lib} {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261026_214621_5191064/work/src/macro/RA1SHD_2048x32M8/RA1SHD_2048x32M8_ss_1p62_125C_syn.lib}]
create_rc_corner -name qa_rc_ss -temperature 125 -cap_table {/lec/pdk/tsmc180/tcb018gbwp7t_290a/TSMCHOME/digital/Back_End/lef/tcb018gbwp7t_270a/techfiles/captable/t018lo_1p6m_typical.captable}
create_delay_corner -name qa_delay_ss -library_set qa_lib_ss -rc_corner qa_rc_ss -si_enabled false
create_analysis_view -name qa_ss -constraint_mode func -delay_corner qa_delay_ss
create_library_set -name qa_lib_ff0 -timing [list {/lec/pdk/tsmc180/tcb018gbwp7t_290a/TSMCHOME/digital/Front_End/timing_power_noise/NLDM/tcb018gbwp7t_270a/tcb018gbwp7tbc.lib} {/lec/pdk/tsmc180/tpd018nv_280a/TSMCHOME/digital/Front_End/timing_power_noise/NLDM/tpd018nv_280a/tpd018nvbc.lib} {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261026_214621_5191064/work/src/macro/RA1SHD_2048x32M8/RA1SHD_2048x32M8_ff_1p98_0C_syn.lib}]
create_rc_corner -name qa_rc_ff0 -temperature 0 -cap_table {/lec/pdk/tsmc180/tcb018gbwp7t_290a/TSMCHOME/digital/Back_End/lef/tcb018gbwp7t_270a/techfiles/captable/t018lo_1p6m_typical.captable}
create_delay_corner -name qa_delay_ff0 -library_set qa_lib_ff0 -rc_corner qa_rc_ff0 -si_enabled false
create_analysis_view -name qa_ff0 -constraint_mode func -delay_corner qa_delay_ff0
create_library_set -name qa_lib_ffm40 -timing [list {/lec/pdk/tsmc180/tcb018gbwp7t_290a/TSMCHOME/digital/Front_End/timing_power_noise/NLDM/tcb018gbwp7t_270a/tcb018gbwp7tlt.lib} {/lec/pdk/tsmc180/tpd018nv_280a/TSMCHOME/digital/Front_End/timing_power_noise/NLDM/tpd018nv_280a/tpd018nvlt.lib} {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261026_214621_5191064/work/src/macro/RA1SHD_2048x32M8/RA1SHD_2048x32M8_ff_1p98_-40C_syn.lib}]
create_rc_corner -name qa_rc_ffm40 -temperature -40 -cap_table {/lec/pdk/tsmc180/tcb018gbwp7t_290a/TSMCHOME/digital/Back_End/lef/tcb018gbwp7t_270a/techfiles/captable/t018lo_1p6m_typical.captable}
create_delay_corner -name qa_delay_ffm40 -library_set qa_lib_ffm40 -rc_corner qa_rc_ffm40 -si_enabled false
create_analysis_view -name qa_ffm40 -constraint_mode func -delay_corner qa_delay_ffm40
set_analysis_view -setup {qa_tt qa_ss qa_ff0 qa_ffm40} -hold {qa_tt qa_ss qa_ff0 qa_ffm40}
set_interactive_constraint_modes {func}
set_propagated_clock [get_clocks {sys_clk jtag_clk}]
set_interactive_constraint_modes {}
timeDesign -postRoute -expandedViews -outDir {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261027_012840_pvt_b72fe2a/pvt/reports}
timeDesign -postRoute -hold -expandedViews -outDir {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261027_012840_pvt_b72fe2a/pvt/reports}
report_timing -view qa_tt -late -max_paths 5 -path_type full_clock > {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261027_012840_pvt_b72fe2a/pvt/tt_setup.log}
report_timing -view qa_tt -early -max_paths 5 -path_type full_clock > {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261027_012840_pvt_b72fe2a/pvt/tt_hold.log}
report_timing -view qa_ss -late -max_paths 5 -path_type full_clock > {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261027_012840_pvt_b72fe2a/pvt/ss_setup.log}
report_timing -view qa_ss -early -max_paths 5 -path_type full_clock > {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261027_012840_pvt_b72fe2a/pvt/ss_hold.log}
report_timing -view qa_ff0 -late -max_paths 5 -path_type full_clock > {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261027_012840_pvt_b72fe2a/pvt/ff0_setup.log}
report_timing -view qa_ff0 -early -max_paths 5 -path_type full_clock > {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261027_012840_pvt_b72fe2a/pvt/ff0_hold.log}
report_timing -view qa_ffm40 -late -max_paths 5 -path_type full_clock > {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261027_012840_pvt_b72fe2a/pvt/ffm40_setup.log}
report_timing -view qa_ffm40 -early -max_paths 5 -path_type full_clock > {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261027_012840_pvt_b72fe2a/pvt/ffm40_hold.log}
puts PVT_REPORTED_NO_ECO
exit 0
