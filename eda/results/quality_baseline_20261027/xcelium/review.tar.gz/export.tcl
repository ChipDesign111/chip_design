set eda_work {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261026_214621_5191064/work}
set sim_inputs {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261027_011413_postsim_xcelium_9577f3c/postsim/inputs}
source {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261027_011413_postsim_xcelium_9577f3c/deploy/server/postsim/export_view.tcl}
