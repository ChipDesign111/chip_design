set eda_work {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261023_225536_e15483c/work}
set sim_inputs {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261026_193037_postsim_e7852dc/postsim/inputs}
source {/home/s2400011041/Desktop/fullstack_chipdesign/uploads/20261026_193037_postsim_e7852dc/deploy/server/postsim/export_view.tcl}
