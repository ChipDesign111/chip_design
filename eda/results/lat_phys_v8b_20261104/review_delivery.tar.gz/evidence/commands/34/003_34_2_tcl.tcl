# Actual sourced body; main SRAM resolved to i_mainmem/i_sram/i_macro
# Current antenna report: ../my_soc_top/my_soc_top_postAntennaFix_antenna.rpt
saveNetlist ../my_soc_top/outputs/manual_final/my_soc_top_flat_lvs.v -excludeLeafCell -flat -phys -excludeCellInst {FILL1BWP7T FILL2BWP7T FILL4BWP7T FILL8BWP7T FILL16BWP7T FILL32BWP7T FILL64BWP7T TAPCELLBWP7T PCORNER PFILLER20 PFILLER10 PFILLER5 PFILLER1 PFILLER05 PFILLER0005 PRCUT PAD60LU_OBV}

