dbGet top.statusRCExtracted
