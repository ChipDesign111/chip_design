`include "axi/typedef.svh"
`include "axi/assign.svh"

module my_soc_top #(
    parameter FPGA_INIT_FILE = ""
) (
    input   logic   clk_i,
    input   logic   rst_ni,
    input   logic   tck_i,
    input   logic   tms_i,
    input   logic   td_i,
    output  logic   td_o
);

  import my_soc_pkg::*;

  logic por_reset_n,boot_ready;
  // Four system-clock edges for debug/POR, then four for the functional SoC.
  // Assertion is asynchronous at both stages; deassertion is synchronous.
  rstgen i_rstgen_por(.clk_i(clk_i),.rst_ni(rst_ni),.test_mode_i(1'b0),.rst_no(por_reset_n),.init_no());
  logic ndmreset;
  logic ndmreset_n;

  rstgen i_rstgen_main (
      .clk_i       (clk_i),
      .rst_ni      (por_reset_n & (~ndmreset)),
      .test_mode_i (1'b0),
      .rst_no      (ndmreset_n),
      .init_no     ()
  );

  AXI_BUS #(
      .AXI_ADDR_WIDTH (32),
      .AXI_DATA_WIDTH (32),
      .AXI_ID_WIDTH   (2),
      .AXI_USER_WIDTH (1)
  ) slave[3:0]();

  AXI_BUS #(
      .AXI_ADDR_WIDTH (32),
      .AXI_DATA_WIDTH (32),
      .AXI_ID_WIDTH   (4),
      .AXI_USER_WIDTH (1)
  ) master[3:0]();

  localparam axi_pkg::xbar_cfg_t AXI_XBAR_CFG = '{
      NoSlvPorts:         4,
      NoMstPorts:         4,
      MaxMstTrans:        1,
      MaxSlvTrans:        1,
      // Fall-through routing: a granted request reaches the selected target
      // in the same cycle. With FallThrough=0 the W channel is routed from a
      // switch-decision FIFO, so AW is accepted one cycle before W and every
      // write costs an extra cycle (measured: SBA image load 4 -> 3 cycles per
      // word). The registered CPU/DMA adapters and the target bridge remain
      // the transaction boundaries; STA checks the longer combinational path.
      FallThrough:        1'b1,
      LatencyMode:        axi_pkg::NO_LATENCY,
      AxiIdWidthSlvPorts: 2,
      AxiIdUsedSlvPorts:  2,
      UniqueIds:          1'b0,
      AxiAddrWidth:       32,
      AxiDataWidth:       32,
      NoAddrRules:        4
  };

  axi_pkg::xbar_rule_32_t [3:0] addr_map;

  localparam int IDX_BOOT = 0;
  localparam int IDX_SRAM = 1;
  localparam int IDX_DM   = 2;
  localparam int IDX_NPU  = 3;

  assign addr_map = '{
      '{ idx: IDX_BOOT, start_addr: BOOT_BASE, end_addr: BOOT_BASE + BOOT_LENGTH },
      '{ idx: IDX_SRAM, start_addr: SRAM_BASE, end_addr: SRAM_BASE + SRAM_LENGTH },
      '{ idx: IDX_DM,   start_addr: DM_BASE,   end_addr: DM_BASE   + DM_LENGTH   },
      '{ idx: IDX_NPU,  start_addr: NPU_BASE,  end_addr: NPU_BASE  + NPU_LENGTH  }
  };

  axi_xbar_intf #(
      .AXI_USER_WIDTH (1),
      .Cfg            (AXI_XBAR_CFG),
      .rule_t         (axi_pkg::xbar_rule_32_t)
  ) i_axi_xbar (
      .clk_i                 (clk_i),
      .rst_ni                (ndmreset_n),
      .test_i                (1'b0),
      .slv_ports             (slave),
      .mst_ports             (master),
      .addr_map_i            (addr_map),
      .en_default_mst_port_i ('0),
      .default_mst_port_i    ('0)
  );

  logic           instr_req;
  logic           instr_gnt;
  logic           instr_rvalid;
  logic [31:0]    instr_addr;
  logic [31:0]    instr_rdata;
  logic           data_req;
  logic           data_gnt;
  logic           data_rvalid;
  logic           data_we;
  logic [3:0]     data_be;
  logic [31:0]    data_addr;
  logic [31:0]    data_wdata;
  logic [31:0]    data_rdata;
  logic           data_valid;
  logic           debug_req_valid;
  logic           debug_req_ready;
  dm::dmi_req_t   debug_req;
  logic           debug_resp_valid;
  logic           debug_resp_ready;
  dm::dmi_resp_t  debug_resp;
  logic           debug_req_irq;
  localparam logic [31:0] DM_HALT_ADDR      = dm::HaltAddress[31:0];
  localparam logic [31:0] DM_EXCEPTION_ADDR = dm::ExceptionAddress[31:0];

  cv32e40p_top #(
      .COREV_PULP      (0),
      .COREV_CLUSTER   (0),
      .FPU             (0),
      .FPU_ADDMUL_LAT  (0),
      .FPU_OTHERS_LAT  (0),
      .ZFINX           (0),
      .NUM_MHPMCOUNTERS(0)
  ) i_cpu (
      .clk_i               (clk_i),
      .rst_ni              (ndmreset_n),
      .pulp_clock_en_i     ('0),
      .scan_cg_en_i        ('0),
      .boot_addr_i         (BOOT_BASE),
      .mtvec_addr_i        (BOOT_BASE),
      .dm_halt_addr_i      (DM_HALT_ADDR),
      .hart_id_i           ('0),
      .dm_exception_addr_i (DM_EXCEPTION_ADDR),
      .instr_req_o         (instr_req),
      .instr_gnt_i         (instr_gnt),
      .instr_rvalid_i      (instr_rvalid),
      .instr_addr_o        (instr_addr),
      .instr_rdata_i       (instr_rdata),
      .data_req_o          (data_req),
      .data_gnt_i          (data_gnt),
      .data_rvalid_i       (data_valid),
      .data_we_o           (data_we),
      .data_be_o           (data_be),
      .data_addr_o         (data_addr),
      .data_wdata_o        (data_wdata),
      .data_rdata_i        (data_rdata),
      .irq_i               (32'b0),
      .irq_ack_o           (),
      .irq_id_o            (),
      .debug_req_i         (debug_req_irq),
      .debug_havereset_o   (),
      .debug_running_o     (),
      .debug_halted_o      (),
      .fetch_enable_i      (boot_ready),
      .core_sleep_o        ()
  );

  `AXI_TYPEDEF_ALL(axi,
                   logic [31:0],
                   logic [3:0],
                   logic [31:0],
                   logic [3:0],
                   logic)

  axi_req_t  instr_axi_req;
  axi_resp_t instr_axi_resp;
  axi_req_t  data_axi_req;
  axi_resp_t data_axi_resp;
  axi_req_t  dm_axi_m_req;
  axi_resp_t dm_axi_m_resp;

  `AXI_ASSIGN_FROM_REQ(slave[0], instr_axi_req)
  `AXI_ASSIGN_TO_RESP(instr_axi_resp, slave[0])
  `AXI_ASSIGN_FROM_REQ(slave[1], data_axi_req)
  `AXI_ASSIGN_TO_RESP(data_axi_resp, slave[1])
  `AXI_ASSIGN_FROM_REQ(slave[2], dm_axi_m_req)
  `AXI_ASSIGN_TO_RESP(dm_axi_m_resp, slave[2])

  assign data_valid = data_rvalid | data_axi_resp.b_valid;

  // Instruction fetch: four 8-word buffers refilled with an INCR burst and
  // prefetched one line ahead, instead of one single-beat AXI transaction per
  // instruction. Hits are granted in the request cycle and return data one
  // cycle later, so the core fetches at one instruction per cycle while the
  // sequential code runs; a line that is not buffered costs one burst, and it
  // becomes hittable word by word as the burst streams in.
  my_ifetch #(
      .axi_req_t   (axi_req_t),
      .axi_rsp_t   (axi_resp_t),
      .LINE_WORDS  (8),
      .SLOTS       (4),
      .SRAM_BASE   (SRAM_BASE),
      .SRAM_LENGTH (SRAM_LENGTH),
      .BOOT_BASE   (BOOT_BASE),
      .BOOT_LENGTH (BOOT_LENGTH)
  ) i_ifetch (
      .clk_i      (clk_i),
      .rst_ni     (ndmreset_n),
      .req_i      (instr_req),
      .addr_i     (instr_addr),
      .gnt_o      (instr_gnt),
      .valid_o    (instr_rvalid),
      .rdata_o    (instr_rdata),
      .axi_req_o  (instr_axi_req),
      .axi_resp_i (instr_axi_resp)
  );

  axi_adapter #(
      .ADDR_WIDTH         (32),
      .DATA_WIDTH         (32),
      .AXI_DATA_WIDTH     (32),
      .AXI_ID_WIDTH       (4),
      .MAX_OUTSTANDING_AW (7),
      .axi_req_t          (axi_req_t),
      .axi_rsp_t          (axi_resp_t)
  ) i_axi_adapter_data (
      .clk_i                 (clk_i),
      .rst_ni                (ndmreset_n),
      .req_i                 (data_req),
      .type_i                (1'b0),
      .amo_i                 (4'b0000),
      .gnt_o                 (data_gnt),
      .addr_i                (data_addr),
      .we_i                  (data_we),
      .wdata_i               (data_wdata),
      .be_i                  (data_be),
      .size_i                (2'b10),
      .id_i                  (4'b0010),
      .valid_o               (data_rvalid),
      .rdata_o               (data_rdata),
      .id_o                  (),
      .critical_word_o       (),
      .critical_word_valid_o (),
      .axi_req_o             (data_axi_req),
      .axi_resp_i            (data_axi_resp)
  );

  dmi_jtag i_dmi_jtag (
      .clk_i           (clk_i),
      .rst_ni          (por_reset_n),
      .dmi_rst_no      (),
      .testmode_i      (1'b0),
      .dmi_req_valid_o (debug_req_valid),
      .dmi_req_ready_i (debug_req_ready),
      .dmi_req_o       (debug_req),
      .dmi_resp_valid_i(debug_resp_valid),
      .dmi_resp_ready_o(debug_resp_ready),
      .dmi_resp_i      (debug_resp),
      .tck_i           (tck_i),
      .tms_i           (tms_i),
      .trst_ni         (rst_ni),
      .td_i            (td_i),
      .td_o            (td_o),
      .tdo_oe_o        ()
  );

  dm::hartinfo_t hartinfo;
  assign hartinfo = '{
      zero1      : '0,
      nscratch   : 2,
      zero0      : '0,
      dataaccess : 1'b1,
      datasize   : dm::DataCount,
      dataaddr   : dm::DataAddr
  };

  logic        dm_slave_req;
  logic        dm_slave_we;
  logic [31:0] dm_slave_addr;
  logic [3:0]  dm_slave_be;
  logic [31:0] dm_slave_wdata;
  logic [31:0] dm_slave_rdata;

  logic        dm_master_req;
  logic [31:0] dm_master_add;
  logic        dm_master_we;
  logic [31:0] dm_master_wdata;
  logic [3:0]  dm_master_be;
  logic        dm_master_gnt;
  logic        dm_master_r_valid;
  logic [31:0] dm_master_r_rdata;

  axi2mem #(
      .AXI_ID_WIDTH   (4),
      .AXI_ADDR_WIDTH (32),
      .AXI_DATA_WIDTH (32),
      .AXI_USER_WIDTH (1)
  ) i_dm_axi2mem (
      .clk_i  (clk_i),
      .rst_ni (por_reset_n),
      .slave  (master[IDX_DM]),
      .req_o  (dm_slave_req),
      .we_o   (dm_slave_we),
      .addr_o (dm_slave_addr),
      .be_o   (dm_slave_be),
      .data_o (dm_slave_wdata),
      .data_i (dm_slave_rdata)
  );

  dm_top #(
      .NrHarts         (1),
      .BusWidth        (32),
      .SelectableHarts (1'b1)
  ) i_dm_top (
      .clk_i            (clk_i),
      .rst_ni           (por_reset_n), // PoR(Power-on Reset)
      .testmode_i       (1'b0),
      .ndmreset_o       (ndmreset),
      .dmactive_o       (),
      .debug_req_o      (debug_req_irq),
      .unavailable_i    ('0),
      .hartinfo_i       (hartinfo),
      .slave_req_i      (dm_slave_req),
      .slave_we_i       (dm_slave_we),
      .slave_addr_i     (dm_slave_addr),
      .slave_be_i       (dm_slave_be),
      .slave_wdata_i    (dm_slave_wdata),
      .slave_rdata_o    (dm_slave_rdata),
      .master_req_o     (dm_master_req),
      .master_add_o     (dm_master_add),
      .master_we_o      (dm_master_we),
      .master_wdata_o   (dm_master_wdata),
      .master_be_o      (dm_master_be),
      .master_gnt_i     (dm_master_gnt),
      .master_r_valid_i (dm_master_r_valid),
      .master_r_rdata_i (dm_master_r_rdata),
      .dmi_rst_ni       (por_reset_n),
      .dmi_req_valid_i  (debug_req_valid),
      .dmi_req_ready_o  (debug_req_ready),
      .dmi_req_i        (debug_req),
      .dmi_resp_valid_o (debug_resp_valid),
      .dmi_resp_ready_i (debug_resp_ready),
      .dmi_resp_o       (debug_resp)
  );

  axi_adapter #(
      .ADDR_WIDTH         (32),
      .DATA_WIDTH         (32),
      .AXI_DATA_WIDTH     (32),
      .AXI_ID_WIDTH       (4),
      .MAX_OUTSTANDING_AW (7),
      .axi_req_t          (axi_req_t),
      .axi_rsp_t          (axi_resp_t)
  ) i_axi_adapter_dm (
      .clk_i                 (clk_i),
      .rst_ni                (por_reset_n),
      .req_i                 (dm_master_req),
      .type_i                (1'b0),
      .amo_i                 (4'b0000),
      .gnt_o                 (dm_master_gnt),
      .addr_i                (dm_master_add),
      .we_i                  (dm_master_we),
      .wdata_i               (dm_master_wdata),
      .be_i                  (dm_master_be),
      .size_i                (2'b10),
      .id_i                  ('0),
      .valid_o               (dm_master_r_valid),
      .rdata_o               (dm_master_r_rdata),
      .id_o                  (),
      .critical_word_o       (),
      .critical_word_valid_o (),
      .axi_req_o             (dm_axi_m_req),
      .axi_resp_i            (dm_axi_m_resp)
  );

  logic        sram_req;
  logic        sram_we;
  logic [31:0] sram_addr;
  logic [31:0] sram_wdata;
  logic [3:0]  sram_be;
  logic [31:0] sram_rdata;
  logic sram_transaction_reset_n;
  // Do not distribute the asynchronously asserting SoC reset directly into
  // the non-reset SRAM command D path. One shared boundary controls both ends;
  // changing only my_mainmem would leave bridge acceptance inconsistent.
  sram_transaction_reset i_sram_transaction_reset (
      .clk_i(clk_i), .reset_request_ni(ndmreset_n),
      .transaction_reset_no(sram_transaction_reset_n)
  );

  logic        boot_req;
  logic        boot_we;
  logic [31:0] boot_addr;
  logic [31:0] boot_wdata;
  logic [31:0] boot_rdata;

  bootram #(.PREINITIALIZED(FPGA_INIT_FILE!="")) i_bootram (
      .sram_write_i(sram_req && sram_we),.sram_addr_i(sram_addr),.sram_be_i(sram_be),
      .ready_o(boot_ready),
      .clk_i (clk_i),
      .rst_ni(ndmreset_n),
      .req_i (boot_req),
      .wen_i (boot_we),
      .addr_i(boot_addr[5:2]),
      .data_i(boot_wdata),
      .data_o(boot_rdata)
  );

  axi2mem #(
      .AXI_ID_WIDTH   (4),
      .AXI_ADDR_WIDTH (32),
      .AXI_DATA_WIDTH (32),
      .AXI_USER_WIDTH (1)
  ) i_axi2boot (
      .clk_i  (clk_i),
      .rst_ni (ndmreset_n),
      .slave  (master[IDX_BOOT]),
      .req_o  (boot_req),
      .we_o   (boot_we),
      .addr_o (boot_addr),
      .be_o   (),
      .data_o (boot_wdata),
      .data_i (boot_rdata)
  );

  my_mainmem #(
      .INIT_FILE(FPGA_INIT_FILE)
  ) i_mainmem (
      .clk_i  (clk_i),
      .rst_ni (sram_transaction_reset_n),
      .req_i  (sram_req),
      .we_i   (sram_we),
      .be_i   (sram_be),
      .addr_i (sram_addr),
      .wdata_i(sram_wdata),
      .rdata_o(sram_rdata)
  );

  axi2mem #(
      .AXI_ID_WIDTH   (4),
      .AXI_ADDR_WIDTH (32),
      .AXI_DATA_WIDTH (32),
      .AXI_USER_WIDTH (1),
      .QUIET_ON_RESET(1'b1)
  ) i_axi2sram (
      .clk_i  (clk_i),
      .rst_ni (sram_transaction_reset_n),
      .slave  (master[IDX_SRAM]),
      .req_o  (sram_req),
      .we_o   (sram_we),
      .addr_o (sram_addr),
      .be_o   (sram_be),
      .data_o (sram_wdata),
      .data_i (sram_rdata)
  );

  logic auto_start,dma_done,dma_error,dma_read_active,dma_write_active;
  logic [31:0] auto_source,auto_dest,auto_words;
  logic        npu_req, npu_we;
  logic npu_user, npu_busy, dma_busy, dma_req, dma_we, dma_conflict;
  logic [4:0] dma_addr;
  logic [31:0] dma_wdata, dma_rdata;
  logic [31:0] npu_addr, npu_wdata, npu_rdata;

  axi2mem #(
      .AXI_ID_WIDTH(4), .AXI_ADDR_WIDTH(32),
      .AXI_DATA_WIDTH(32), .AXI_USER_WIDTH(1)
  ) i_axi2npu (
      .clk_i(clk_i), .rst_ni(ndmreset_n), .slave(master[IDX_NPU]),
      .req_o(npu_req), .we_o(npu_we), .addr_o(npu_addr), .be_o(),
      .data_o(npu_wdata), .data_i(npu_rdata), .user_i('0), .user_o(npu_user)
  );

  my_npu_subsystem i_npu_subsystem (
      .clk_i(clk_i), .rst_ni(ndmreset_n), .req_i(npu_req), .we_i(npu_we),
      .addr_i(npu_addr), .wdata_i(npu_wdata), .rdata_o(npu_rdata),
      .auto_start_o(auto_start),.auto_source_o(auto_source),.auto_dest_o(auto_dest),.auto_words_o(auto_words),
      .dma_done_i(dma_done),.dma_error_i(dma_error),.dma_read_i(dma_read_active),.dma_write_active_i(dma_write_active),
      .dma_write_i(npu_user), .dma_busy_i(dma_busy), .dma_rdata_i(dma_rdata),
      .dma_req_o(dma_req), .dma_we_o(dma_we), .dma_addr_o(dma_addr),
      .dma_wdata_o(dma_wdata), .dma_conflict_o(dma_conflict), .npu_busy_o(npu_busy)
  );

  har_dma_axi i_dma (
      .clk_i(clk_i), .rst_ni(ndmreset_n), .master(slave[3]),
      .reg_req_i(dma_req), .reg_we_i(dma_we), .reg_addr_i(dma_addr),
      .reg_wdata_i(dma_wdata), .reg_rdata_o(dma_rdata),
      .auto_start_i(auto_start),.auto_source_i(auto_source),.auto_dest_i(auto_dest),.auto_words_i(auto_words),
      .done_o(dma_done),.error_o(dma_error),.read_active_o(dma_read_active),.write_active_o(dma_write_active),
      .npu_busy_i(npu_busy), .conflict_i(dma_conflict), .busy_o(dma_busy)
  );
endmodule
